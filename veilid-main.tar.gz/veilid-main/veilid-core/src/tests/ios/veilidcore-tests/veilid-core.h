//
//  veilid-core.h
//  veilid-core-tests
//
//  Created by JSmith on 7/6/21.
//

#ifndef veilid_core_h
#define veilid_core_h

void run_veilid_core_tests(void);

#endif /* veilid-core_h */
