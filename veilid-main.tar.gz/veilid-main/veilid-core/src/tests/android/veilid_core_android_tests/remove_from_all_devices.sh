#!/bin/bash
./adb+.sh uninstall com.veilid.veilid_core_android_tests

