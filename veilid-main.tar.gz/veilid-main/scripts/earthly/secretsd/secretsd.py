#!/usr/bin/env python3
import secretsd.__main__
