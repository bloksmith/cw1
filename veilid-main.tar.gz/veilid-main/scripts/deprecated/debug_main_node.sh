#!/bin/bash
exec ./run_local_test.py 20 -w 0 --config-file ./local-test.yml $1
