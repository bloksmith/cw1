#!/bin/bash
exec ./run_local_test.py 4 --config-file ./local-test.yml $@


