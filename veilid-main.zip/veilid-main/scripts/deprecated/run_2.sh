#!/bin/bash
exec ./run_local_test.py 2 --config-file ./local-test.yml $@


